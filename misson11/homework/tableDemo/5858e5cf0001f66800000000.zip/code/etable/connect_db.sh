mysql -u root -p123 -D etable
