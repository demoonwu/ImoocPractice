#!/bin/sh

sudo /data0/mysql5536/bin/mysqld_safe &
