<?php
	$viewconfig = array('left_delimiter'=>'{', 'right_delimiter' => '}', 'template_dir' => 'tpl', 'compile_dir' => 'template_c');
?>