<?php /* Smarty version Smarty-3.1.16, created on 2014-03-23 14:16:28
         compiled from "tpl\test.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2198453257ef276df25-26750253%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '993d0a8df898c0f4072435541bc301f02265491a' => 
    array (
      0 => 'tpl\\test.tpl',
      1 => 1395584106,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2198453257ef276df25-26750253',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_53257ef27b9763_36982502',
  'variables' => 
  array (
    'str' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53257ef27b9763_36982502')) {function content_53257ef27b9763_36982502($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['str']->value;?>

<?php }} ?>
