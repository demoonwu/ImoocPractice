<?php /*%%SmartyHeaderCode:1397953255843ee4fe7-00226794%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '993d0a8df898c0f4072435541bc301f02265491a' => 
    array (
      0 => 'tpl\\test.tpl',
      1 => 1394956449,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1397953255843ee4fe7-00226794',
  'cache_lifetime' => 120,
  'version' => 'Smarty-3.1.17',
  'unifunc' => 'content_532558a5e8d494_91026218',
  'variables' => 
  array (
    'arr' => 0,
  ),
  'has_nocache_code' => false,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_532558a5e8d494_91026218')) {function content_532558a5e8d494_91026218($_smarty_tpl) {?>smarty��ѧϰ С��
<?php }} ?>
