 <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>常用操作</a>
                    <ul class="sub-menu">
                        <li><a href="./controlPanelUser.php"><i class="icon-font">&#xe008;</i>用户管理</a></li>
                        <li><a href="./controlPanelContent.php"><i class="icon-font">&#xe006;</i>通讯录管理</a></li>
                    </ul>
                </li>
            </ul>
        </div>