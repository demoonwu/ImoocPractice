<?php
include_once('./public/pdodbconnect.php');
echo "<pre>";
$user=$_POST;
$user['password']=md5($_POST['password']);
$user['createdTime']=time();
$field=array_keys($user);
$field=implode(",",$field);
$value="'".implode("','",$user)."'";
$sql=<<<EOF
	INSERT INTO USER ({$field}) VALUES ({$value});
EOF;
$sql=htmlspecialchars($sql);//防止xss攻击
try{
	$link->setAttribute(PDO::ATTR_AUTOCOMMIT,0);
	//事务处理开始
	$link->beginTransaction();
	$res=$link->exec($sql);
	if($res==0){
		throw new PDOException("注册失败");
	};
	echo "已注册成功{$res}位,您是本网站第".$link->lastInsertId()."位注册成功的用户,{$user['username']}注册成功";
	//事务处理结束
	$link->commit();
	$link->setAttribute(PDO::ATTR_AUTOCOMMIT,1);
}catch(PDOException $e){
	$link->rollBack();
	echo $e->getMessage();
	$link->setAttribute(PDO::ATTR_AUTOCOMMIT,1);
}

//htmlspecialchars;