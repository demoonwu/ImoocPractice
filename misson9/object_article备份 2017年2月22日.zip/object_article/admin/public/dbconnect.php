<?php
	$link=mysqli_connect("localhost","root","","demoarticle");
	if(mysqli_connect_errno()){
		exit("连接数据库失败".mysql_error());
	}
	mysqli_set_charset($link,"utf8");
	// $sql='INSERT INTO USER (username,password,email,sex,info,pic,createdTime)VALUES("user2","e10adc3949ba59abbe56e057f20f883e","user2@qq.com","男","user2info","20170218040333710.jpg","1487387013");';
	// mysqli_query($link,$sql);
?>