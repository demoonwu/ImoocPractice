<?php
	include("../public/acl.php");
?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>后台管理</title>
    <link rel="stylesheet" type="text/css" href="../css/common.css"/>
    <link rel="stylesheet" type="text/css" href="../css/main.css"/>
    <script type="text/javascript" src="../js/libs/modernizr.min.js"></script>
</head>
<body>
<div class="topbar-wrap white">
<?php
include("../public/topbar.php"); 
?>
</div>
<div class="container clearfix">
    <?php 
		include("../public/sidebar.php");
	?>
	<!--/sidebar-->
    <div class="main-wrap">
        <div class="crumb-wrap">
            <div class="crumb-list"><i class="icon-font"></i><a href="../index.php">首页</a><span class="crumb-step">&gt;</span><span class="crumb-name">用户管理</span></div>
        </div>
        <div class="search-wrap">
            <div class="search-content">
                <form action="/jscss/admin/design/index" method="post">
                    <table class="search-tab">
                        <tr>
                            <th width="70">用户名:</th>
                            <td><input class="common-text" placeholder="用户名" name="keywords" value="" id="" type="text"></td>
                            <td><input class="btn btn-primary btn2" name="sub" value="查询" type="submit"></td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
        <div class="result-wrap">
            <form name="myform" id="myform" method="post">
                <div class="result-title">
                    <div class="result-list">
                        <a href="addUser.php"><i class="icon-font"></i>新增用户</a>
                        <a id="batchDel" href="javascript:void(0)"><i class="icon-font"></i>批量删除</a>
                    </div>
                </div>
                <div class="result-content">
                    <table class="result-tab" width="100%">
                        <tr>
                            <th class="tc" width="5%"><input class="allChoose" name="" type="checkbox"></th>                        
                            <th>ID</th>
                            <th>作者</th>
                            <th>状态</th>
                            <th>标题</th>
                            <th>摘要</th>
                            <th>文章</th>
							<th>上传者</th>
							<th>备注</th>
                            <th>上传时间</th>
                            <th>操作</th>
                        </tr>
						<?php
							include("../public/dbconnect.php");
							$sql="SELECT ID,USERNAME,EMAIL,STATUS,SEX,PIC,isAdmin,INFO,CREATEDTIME FROM USER;";
							$res=mysqli_query($link,$sql);
							while(list($ID,$USERNAME,$EMAIL,$STATUS,$SEX,$PIC,$isAdmin,$INFO,$CREATEDTIME)=mysqli_fetch_row($res)){
						?>
                        <tr>
                            <td class="tc"><input name="id[]" value="<?php  echo $ID;?>" type="checkbox"></td>
                            <td><?php  echo $ID?></td>
							<td><?php  echo $USERNAME?></td>
                            <td><?php  echo $STATUS==1?"开启":"关闭"?></td>
                            <td><img src="../uploads/<?php echo $PIC?>" width=30></td>
                            <td><?php  echo $EMAIL?></td>
							<td><?php  echo $SEX?></td>
							<td><?php  echo $isAdmin==2?"是":"否"?></td>
							<td><?php  echo $INFO?></td>
                            <td><?php   date_default_timezone_set('prc');echo date("Y年m月d日 H:i:s",$CREATEDTIME);?></td>
                            <td>
                                <a class="link-update" href="./alterUser.php?id=<?php echo $ID?>">修改</a>
                                <a class="link-del" href="./deleteUser.php?id=<?php echo $ID?>&&pic=<?php echo $PIC?>">删除</a>
                            </td>
                        </tr>
                        <?php
							static $i=0;
							$i++;
							}
						?>
						</table>
                    <div class="list-page"> <?php echo $i;unset($i);?> 条 1/1 页</div>
                </div>
            </form>
        </div>
    </div>
    <!--/main-->
</div>
</body>
</html>