<nav class="navbar navbar-default" role="navigation">
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<div class="navbar-header"> 
					<!-- Mobile Toggle Menu Button -->
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle visible-xs-block" data-toggle="collapse" data-target="#fh5co-navbar" aria-expanded="false" aria-controls="navbar"><i></i></a>
					<a class="navbar-brand" href="/practice/misson9/object_article/index.php">首页</a>
					</div>
					<div id="fh5co-navbar" class="navbar-collapse collapse">
						<ul class="nav navbar-nav navbar-right">
							<li class="active"><a href="/practice/misson9/object_article/index.php"><span>首页<span class="border"></span></span></a></li>
							<li><a href="right-sidebar.html"><span>登录<span class="border"></span></span></a></li>
							<li><a href="/practice/misson9/object_article/author.php"><span>作者列表<span class="border"></span></span></a></li>
							<li><a href="/practice/misson9/object_article/article/article.php"><span>上传文章<span class="border"></span></span></a></li>
							<li><a href="left-sidebar.html"><span>退出<span class="border"></span></span></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</nav>